import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Generator from './pages/Generator'
import Analytics from './pages/Analytics'

function App() {
    return (
        <Layout>
            <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/generate" element={<Generator />} />
                <Route path="/analytics" element={<Analytics />} />
            </Routes>
        </Layout>
    )
}

export default App
