import { useState, useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import axios from 'axios'

export default function Generator() {
    const location = useLocation()
    const [formData, setFormData] = useState({
        topic: 'FLN',
        cluster: location.state?.selectedCluster || 'A',
        duration: '2 hours',
        language: 'English'
    })

    const [generating, setGenerating] = useState(false)
    const [generatedModule, setGeneratedModule] = useState(null)
    const [error, setError] = useState(null)
    const [progress, setProgress] = useState(0)

    const topics = ['FLN', 'Classroom Management', 'Tech Integration']
    const clusters = ['A', 'B', 'C']
    const durations = ['1 hour', '2 hours', 'Half day']
    const languages = ['Hindi', 'English']

    useEffect(() => {
        if (generating) {
            const interval = setInterval(() => {
                setProgress(prev => {
                    if (prev >= 95) return prev
                    return prev + 5
                })
            }, 1500)
            return () => clearInterval(interval)
        }
    }, [generating])

    const handleSubmit = async (e) => {
        e.preventDefault()
        setGenerating(true)
        setError(null)
        setProgress(0)
        setGeneratedModule(null)

        try {
            const response = await axios.post('/api/generate', formData)
            setProgress(100)
            setTimeout(() => {
                setGeneratedModule(response.data.module)
                setGenerating(false)
            }, 500)
        } catch (err) {
            console.error('Generation error:', err)
            setError('Failed to generate module. Please try again.')
            setGenerating(false)
            setProgress(0)
        }
    }

    const handleDownloadPDF = async () => {
        if (!generatedModule) return

        try {
            const response = await axios.post('/api/download-pdf', {
                module: generatedModule,
                formData: formData
            }, {
                responseType: 'blob'
            })

            const url = window.URL.createObjectURL(new Blob([response.data]))
            const link = document.createElement('a')
            link.href = url
            link.setAttribute('download', `training-module-${Date.now()}.pdf`)
            document.body.appendChild(link)
            link.click()
            link.remove()
        } catch (err) {
            console.error('PDF download error:', err)
            alert('Failed to download PDF. Please try again.')
        }
    }

    return (
        <div className="max-w-6xl mx-auto fade-in">
            {/* Page Header */}
            <div className="relative bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 rounded-3xl shadow-2xl p-8 mb-8 text-white overflow-hidden">
                {/* Decorative elements */}
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
                <div className="absolute bottom-0 left-0 w-48 h-48 bg-purple-500/20 rounded-full blur-2xl -ml-24 -mb-24"></div>

                <div className="relative z-10 flex items-center justify-between">
                    <div className="flex-1">
                        <div className="flex items-center mb-4">
                            <div className="bg-white/20 backdrop-blur-sm p-4 rounded-2xl mr-4">
                                <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
                                </svg>
                            </div>
                            <div>
                                <h1 className="text-4xl font-black mb-2">AI Training Generator</h1>
                                <p className="text-purple-100 text-lg">
                                    Generate personalized teacher training modules in 30 seconds using GPT-4
                                </p>
                            </div>
                        </div>
                        <div className="flex items-center space-x-4">
                            <div className="flex items-center bg-white/15 backdrop-blur-md px-4 py-2 rounded-full border border-white/30">
                                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M13 7H7v6h6V7z" />
                                    <path fillRule="evenodd" d="M7 2a1 1 0 012 0v1h2V2a1 1 0 112 0v1h2a2 2 0 012 2v2h1a1 1 0 110 2h-1v2h1a1 1 0 110 2h-1v2a2 2 0 01-2 2h-2v1a1 1 0 11-2 0v-1H9v1a1 1 0 11-2 0v-1H5a2 2 0 01-2-2v-2H2a1 1 0 110-2h1V9H2a1 1 0 010-2h1V5a2 2 0 012-2h2V2zM5 5h10v10H5V5z" clipRule="evenodd" />
                                </svg>
                                <span className="font-semibold text-sm">GPT-4 Powered</span>
                            </div>
                            <div className="flex items-center bg-white/15 backdrop-blur-md px-4 py-2 rounded-full border border-white/30">
                                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                                </svg>
                                <span className="font-semibold text-sm">~30 Seconds</span>
                            </div>
                            <div className="flex items-center bg-white/15 backdrop-blur-md px-4 py-2 rounded-full border border-white/30">
                                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                                </svg>
                                <span className="font-semibold text-sm">PDF Export</span>
                            </div>
                        </div>
                    </div>
                    <div className="hidden xl:block">
                        <div className="w-32 h-32 relative">
                            <div className="absolute inset-0 bg-gradient-to-br from-yellow-300 to-orange-400 rounded-3xl animate-pulse shadow-2xl flex items-center justify-center rotate-12">
                                <svg className="w-20 h-20 text-white -rotate-12" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M9 4.804A7.968 7.968 0 005.5 4c-1.255 0-2.443.29-3.5.804v10A7.969 7.969 0 015.5 14c1.669 0 3.218.51 4.5 1.385A7.962 7.962 0 0114.5 14c1.255 0 2.443.29 3.5.804v-10A7.968 7.968 0 0014.5 4c-1.255 0-2.443.29-3.5.804V12a1 1 0 11-2 0V4.804z" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Generator Form */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1">
                    <div className="card sticky top-24 shadow-xl border-2 border-gray-100">
                        <div className="flex items-center mb-6 pb-4 border-b-2 border-gray-100">
                            <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-3 rounded-xl mr-3">
                                <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
                                </svg>
                            </div>
                            <h2 className="text-2xl font-black text-gray-800">Training Parameters</h2>
                        </div>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            {/* Topic Selection */}
                            <div className="relative">
                                <label className="flex items-center text-sm font-bold text-gray-700 mb-3">
                                    <div className="bg-blue-100 p-2 rounded-lg mr-2">
                                        <svg className="w-4 h-4 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M9 4.804A7.968 7.968 0 005.5 4c-1.255 0-2.443.29-3.5.804v10A7.969 7.969 0 015.5 14c1.669 0 3.218.51 4.5 1.385A7.962 7.962 0 0114.5 14c1.255 0 2.443.29 3.5.804v-10A7.968 7.968 0 0014.5 4c-1.255 0-2.443.29-3.5.804V12a1 1 0 11-2 0V4.804z" />
                                        </svg>
                                    </div>
                                    Training Topic
                                </label>
                                <select
                                    value={formData.topic}
                                    onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                                    className="input-field"
                                    disabled={generating}
                                >
                                    {topics.map(topic => (
                                        <option key={topic} value={topic}>{topic}</option>
                                    ))}
                                </select>
                            </div>

                            {/* Cluster Selection */}
                            <div className="relative">
                                <label className="flex items-center text-sm font-bold text-gray-700 mb-3">
                                    <div className="bg-green-100 p-2 rounded-lg mr-2">
                                        <svg className="w-4 h-4 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                                        </svg>
                                    </div>
                                    Target Cluster
                                </label>
                                <select
                                    value={formData.cluster}
                                    onChange={(e) => setFormData({ ...formData, cluster: e.target.value })}
                                    className="input-field"
                                    disabled={generating}
                                >
                                    {clusters.map(cluster => (
                                        <option key={cluster} value={cluster}>Cluster {cluster}</option>
                                    ))}
                                </select>
                            </div>

                            {/* Duration Selection */}
                            <div className="relative">
                                <label className="flex items-center text-sm font-bold text-gray-700 mb-3">
                                    <div className="bg-purple-100 p-2 rounded-lg mr-2">
                                        <svg className="w-4 h-4 text-purple-600" fill="currentColor" viewBox="0 0 20 20">
                                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                                        </svg>
                                    </div>
                                    Duration
                                </label>
                                <select
                                    value={formData.duration}
                                    onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                                    className="input-field"
                                    disabled={generating}
                                >
                                    {durations.map(duration => (
                                        <option key={duration} value={duration}>{duration}</option>
                                    ))}
                                </select>
                            </div>

                            {/* Language Selection */}
                            <div className="relative">
                                <label className="flex items-center text-sm font-bold text-gray-700 mb-3">
                                    <div className="bg-orange-100 p-2 rounded-lg mr-2">
                                        <svg className="w-4 h-4 text-orange-600" fill="currentColor" viewBox="0 0 20 20">
                                            <path fillRule="evenodd" d="M7 2a1 1 0 011 1v1h3a1 1 0 110 2H9.578a18.87 18.87 0 01-1.724 4.78c.29.354.596.696.914 1.026a1 1 0 11-1.44 1.389c-.188-.196-.373-.396-.554-.6a19.098 19.098 0 01-3.107 3.567 1 1 0 01-1.334-1.49 17.087 17.087 0 003.13-3.733 18.992 18.992 0 01-1.487-2.494 1 1 0 111.79-.89c.234.47.489.928.764 1.372.417-.934.752-1.913.997-2.927H3a1 1 0 110-2h3V3a1 1 0 011-1zm6 6a1 1 0 01.894.553l2.991 5.982a.869.869 0 01.02.037l.99 1.98a1 1 0 11-1.79.895L15.383 16h-4.764l-.724 1.447a1 1 0 11-1.788-.894l.99-1.98.019-.038 2.99-5.982A1 1 0 0113 8zm-1.382 6h2.764L13 11.236 11.618 14z" />
                                        </svg>
                                    </div>
                                    Language
                                </label>
                                <select
                                    value={formData.language}
                                    onChange={(e) => setFormData({ ...formData, language: e.target.value })}
                                    className="input-field"
                                    disabled={generating}
                                >
                                    {languages.map(language => (
                                        <option key={language} value={language}>{language}</option>
                                    ))}
                                </select>
                            </div>

                            {/* Generate Button */}
                            <button
                                type="submit"
                                disabled={generating}
                                className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                            >
                                {generating ? (
                                    <>
                                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                                        Generating...
                                    </>
                                ) : (
                                    <>
                                        <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                            <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
                                        </svg>
                                        Generate with AI
                                    </>
                                )}
                            </button>
                        </form>

                        {/* Info Box */}
                        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                            <div className="flex items-start">
                                <svg className="w-5 h-5 text-blue-600 mr-2 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                                </svg>
                                <div className="text-sm text-blue-800">
                                    <p className="font-semibold mb-1">AI-Powered Generation</p>
                                    <p>Using GPT-4 to create contextually relevant training modules tailored to your cluster's needs.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Results Section */}
                <div className="lg:col-span-2">
                    {generating && (
                        <div className="card">
                            <div className="text-center py-12">
                                <div className="relative inline-block mb-6">
                                    <div className="animate-spin rounded-full h-20 w-20 border-b-4 border-primary"></div>
                                    <div className="absolute inset-0 flex items-center justify-center">
                                        <svg className="w-10 h-10 text-primary" fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M13 7H7v6h6V7z" />
                                            <path fillRule="evenodd" d="M7 2a1 1 0 012 0v1h2V2a1 1 0 112 0v1h2a2 2 0 012 2v2h1a1 1 0 110 2h-1v2h1a1 1 0 110 2h-1v2a2 2 0 01-2 2h-2v1a1 1 0 11-2 0v-1H9v1a1 1 0 11-2 0v-1H5a2 2 0 01-2-2v-2H2a1 1 0 110-2h1V9H2a1 1 0 010-2h1V5a2 2 0 012-2h2V2zM5 5h10v10H5V5z" clipRule="evenodd" />
                                        </svg>
                                    </div>
                                </div>
                                <h3 className="text-2xl font-bold text-gray-800 mb-2">AI is generating your training module...</h3>
                                <p className="text-gray-600 mb-6">This usually takes about 30 seconds</p>

                                {/* Progress Bar */}
                                <div className="max-w-md mx-auto">
                                    <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
                                        <div
                                            className="bg-gradient-to-r from-primary to-blue-600 h-3 rounded-full transition-all duration-500"
                                            style={{ width: `${progress}%` }}
                                        ></div>
                                    </div>
                                    <p className="text-sm text-gray-600 font-medium">{progress}% Complete</p>
                                </div>
                            </div>
                        </div>
                    )}

                    {error && (
                        <div className="card bg-red-50 border-2 border-red-200">
                            <div className="flex items-center">
                                <svg className="w-6 h-6 text-red-600 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                                </svg>
                                <div>
                                    <h3 className="font-bold text-red-800">Error</h3>
                                    <p className="text-red-700">{error}</p>
                                </div>
                            </div>
                        </div>
                    )}

                    {generatedModule && !generating && (
                        <div className="space-y-6 fade-in">
                            {/* Module Header */}
                            <div className="card bg-gradient-to-r from-primary to-blue-700 text-white">
                                <div className="flex items-start justify-between">
                                    <div className="flex-1">
                                        <h2 className={`text-3xl font-bold mb-3 ${formData.language === 'Hindi' ? 'hindi-text' : ''}`}>
                                            {generatedModule.title}
                                        </h2>
                                        <div className="flex flex-wrap gap-3">
                                            <Badge icon="📚" label={formData.topic} />
                                            <Badge icon="👥" label={`Cluster ${formData.cluster}`} />
                                            <Badge icon="⏱️" label={formData.duration} />
                                            <Badge icon="🌐" label={formData.language} />
                                        </div>
                                    </div>
                                    <button
                                        onClick={handleDownloadPDF}
                                        className="bg-white text-primary px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-all duration-200 shadow-lg hover:shadow-xl flex items-center"
                                    >
                                        <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                            <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                                        </svg>
                                        Download PDF
                                    </button>
                                </div>
                            </div>

                            {/* Session Plan */}
                            <div className="card">
                                <h3 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                                    <svg className="w-6 h-6 mr-2 text-primary" fill="currentColor" viewBox="0 0 20 20">
                                        <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
                                    </svg>
                                    Session Plan
                                </h3>
                                <div className="overflow-x-auto">
                                    <table className="w-full">
                                        <thead>
                                            <tr className="bg-gray-50 border-b-2 border-gray-200">
                                                <th className="px-4 py-3 text-left text-sm font-bold text-gray-700">Time</th>
                                                <th className="px-4 py-3 text-left text-sm font-bold text-gray-700">Activity</th>
                                                <th className="px-4 py-3 text-left text-sm font-bold text-gray-700">Objective</th>
                                            </tr>
                                        </thead>
                                        <tbody className={formData.language === 'Hindi' ? 'hindi-text' : ''}>
                                            {generatedModule.session_plan.map((session, index) => (
                                                <tr key={index} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                                                    <td className="px-4 py-3 font-semibold text-primary">{session.time}</td>
                                                    <td className="px-4 py-3">{session.activity}</td>
                                                    <td className="px-4 py-3 text-gray-600">{session.objective}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            {/* Teaching Activities */}
                            <div className="card">
                                <h3 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                                    <svg className="w-6 h-6 mr-2 text-primary" fill="currentColor" viewBox="0 0 20 20">
                                        <path d="M9 4.804A7.968 7.968 0 005.5 4c-1.255 0-2.443.29-3.5.804v10A7.969 7.969 0 015.5 14c1.669 0 3.218.51 4.5 1.385A7.962 7.962 0 0114.5 14c1.255 0 2.443.29 3.5.804v-10A7.968 7.968 0 0014.5 4c-1.255 0-2.443.29-3.5.804V12a1 1 0 11-2 0V4.804z" />
                                    </svg>
                                    Teaching Activities
                                </h3>
                                <div className="space-y-4">
                                    {generatedModule.activities.map((activity, index) => (
                                        <div key={index} className={`p-5 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border-l-4 border-primary ${formData.language === 'Hindi' ? 'hindi-text' : ''}`}>
                                            <h4 className="font-bold text-lg text-gray-800 mb-2">
                                                {index + 1}. {activity.title}
                                            </h4>
                                            <p className="text-gray-700 mb-3">{activity.instructions}</p>
                                            {activity.materials && (
                                                <div className="flex items-start text-sm text-gray-600">
                                                    <svg className="w-4 h-4 mr-2 mt-0.5 text-primary" fill="currentColor" viewBox="0 0 20 20">
                                                        <path fillRule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
                                                    </svg>
                                                    <span><strong>Materials:</strong> {activity.materials}</span>
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Assessment Questions */}
                            <div className="card">
                                <h3 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                                    <svg className="w-6 h-6 mr-2 text-primary" fill="currentColor" viewBox="0 0 20 20">
                                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                                    </svg>
                                    Assessment Questions
                                </h3>
                                <div className={`space-y-3 ${formData.language === 'Hindi' ? 'hindi-text' : ''}`}>
                                    {generatedModule.assessments.map((assessment, index) => (
                                        <div key={index} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                                            <div className="flex items-start">
                                                <span className="flex-shrink-0 w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center font-bold mr-3">
                                                    {index + 1}
                                                </span>
                                                <div className="flex-1">
                                                    <p className="text-gray-800 font-medium">{assessment.question}</p>
                                                    <span className="inline-block mt-2 px-3 py-1 bg-blue-100 text-blue-800 text-xs font-semibold rounded-full">
                                                        {assessment.type}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}

                    {!generating && !generatedModule && !error && (
                        <div className="card text-center py-16">
                            <svg className="w-24 h-24 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            <h3 className="text-xl font-bold text-gray-600 mb-2">No module generated yet</h3>
                            <p className="text-gray-500">Select your parameters and click "Generate with AI" to create a training module</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}

function Badge({ icon, label }) {
    return (
        <div className="bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-semibold flex items-center">
            <span className="mr-2">{icon}</span>
            {label}
        </div>
    )
}
