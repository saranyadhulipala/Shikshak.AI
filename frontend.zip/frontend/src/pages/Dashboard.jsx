import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

export default function Dashboard() {
    const navigate = useNavigate()
    const [clusters, setClusters] = useState([])
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        fetchClusters()
    }, [])

    const fetchClusters = async () => {
        try {
            const response = await axios.get('/api/analyze')
            setClusters(response.data.clusters)
        } catch (error) {
            console.error('Error fetching clusters:', error)
            // Use fallback data if API fails
            setClusters(getFallbackClusters())
        } finally {
            setLoading(false)
        }
    }

    const getFallbackClusters = () => [
        {
            id: 'A',
            name: 'Cluster A - Rural Teachers',
            teacher_count: 650,
            avg_score: 62,
            primary_need: 'Behavior Management',
            description: 'Rural teachers with low behavior management scores, need engagement strategies',
            color: 'from-blue-500 to-blue-700'
        },
        {
            id: 'B',
            name: 'Cluster B - Urban Teachers',
            teacher_count: 800,
            avg_score: 78,
            primary_need: 'Advanced Science Resources',
            description: 'Urban teachers with high pedagogy, need advanced science teaching resources',
            color: 'from-green-500 to-green-700'
        },
        {
            id: 'C',
            name: 'Cluster C - Tribal Teachers',
            teacher_count: 550,
            avg_score: 58,
            primary_need: 'Multilingual Teaching',
            description: 'Tribal area teachers with multilingual needs and low infrastructure',
            color: 'from-purple-500 to-purple-700'
        }
    ]

    if (loading) {
        return (
            <div className="flex items-center justify-center h-96">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-primary mx-auto mb-4"></div>
                    <p className="text-gray-600 font-medium">Loading clusters...</p>
                </div>
            </div>
        )
    }

    return (
        <div className="fade-in">
            {/* Hero Section */}
            <div className="relative bg-gradient-to-br from-indigo-600 via-blue-600 to-purple-700 rounded-3xl shadow-2xl p-8 md:p-12 mb-8 text-white overflow-hidden">
                {/* Decorative Background Elements */}
                <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl -mr-48 -mt-48"></div>
                <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl -ml-32 -mb-32"></div>

                <div className="relative z-10 flex items-center justify-between">
                    <div className="flex-1">
                        <div className="flex items-center mb-4">
                            <div className="bg-white/20 backdrop-blur-sm p-3 rounded-2xl mr-4">
                                <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z" />
                                </svg>
                            </div>
                            <div>
                                <h1 className="text-5xl font-bold mb-2">Welcome to Shikshak.AI</h1>
                                <div className="flex items-center space-x-2">
                                    <span className="px-3 py-1 bg-yellow-400 text-yellow-900 rounded-full text-sm font-bold">✨ AI-Powered</span>
                                    <span className="px-3 py-1 bg-green-400 text-green-900 rounded-full text-sm font-bold">⚡ Lightning Fast</span>
                                </div>
                            </div>
                        </div>
                        <p className="text-xl text-blue-50 mb-6 max-w-2xl">
                            Generate personalized teacher training modules in 30 seconds using GPT-4.
                            Tailored for Indian educators, supporting both Hindi and English.
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-3xl">
                            <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/20 hover:bg-white/20 transition-all">
                                <div className="flex items-center mb-2">
                                    <div className="bg-blue-400 p-2 rounded-lg mr-3">
                                        <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M13 7H7v6h6V7z" />
                                            <path fillRule="evenodd" d="M7 2a1 1 0 012 0v1h2V2a1 1 0 112 0v1h2a2 2 0 012 2v2h1a1 1 0 110 2h-1v2h1a1 1 0 110 2h-1v2a2 2 0 01-2 2h-2v1a1 1 0 11-2 0v-1H9v1a1 1 0 11-2 0v-1H5a2 2 0 01-2-2v-2H2a1 1 0 110-2h1V9H2a1 1 0 010-2h1V5a2 2 0 012-2h2V2zM5 5h10v10H5V5z" clipRule="evenodd" />
                                        </svg>
                                    </div>
                                    <span className="font-bold text-lg">AI-Powered</span>
                                </div>
                                <p className="text-blue-100 text-sm">GPT-4 generates contextual training content</p>
                            </div>
                            <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/20 hover:bg-white/20 transition-all">
                                <div className="flex items-center mb-2">
                                    <div className="bg-green-400 p-2 rounded-lg mr-3">
                                        <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                                        </svg>
                                    </div>
                                    <span className="font-bold text-lg">30 Seconds</span>
                                </div>
                                <p className="text-blue-100 text-sm">Complete training modules in half a minute</p>
                            </div>
                            <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/20 hover:bg-white/20 transition-all">
                                <div className="flex items-center mb-2">
                                    <div className="bg-purple-400 p-2 rounded-lg mr-3">
                                        <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M7 2a1 1 0 011 1v1h3a1 1 0 110 2H9.578a18.87 18.87 0 01-1.724 4.78c.29.354.596.696.914 1.026a1 1 0 11-1.44 1.389c-.188-.196-.373-.396-.554-.6a19.098 19.098 0 01-3.107 3.567 1 1 0 01-1.334-1.49 17.087 17.087 0 003.13-3.733 18.992 18.992 0 01-1.487-2.494 1 1 0 111.79-.89c.234.47.489.928.764 1.372.417-.934.752-1.913.997-2.927H3a1 1 0 110-2h3V3a1 1 0 011-1zm6 6a1 1 0 01.894.553l2.991 5.982a.869.869 0 01.02.037l.99 1.98a1 1 0 11-1.79.895L15.383 16h-4.764l-.724 1.447a1 1 0 11-1.788-.894l.99-1.98.019-.038 2.99-5.982A1 1 0 0113 8zm-1.382 6h2.764L13 11.236 11.618 14z" />
                                        </svg>
                                    </div>
                                    <span className="font-bold text-lg">Bilingual</span>
                                </div>
                                <p className="text-blue-100 text-sm">Full support for Hindi & English content</p>
                            </div>
                        </div>
                    </div>
                    <div className="hidden xl:block ml-8">
                        <div className="relative">
                            {/* Decorative illustration using CSS */}
                            <div className="w-64 h-64 relative">
                                {/* Central AI brain */}
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <div className="w-32 h-32 bg-gradient-to-br from-yellow-300 to-orange-400 rounded-full animate-pulse shadow-2xl flex items-center justify-center">
                                        <svg className="w-20 h-20 text-white" fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M13 7H7v6h6V7z" />
                                            <path fillRule="evenodd" d="M7 2a1 1 0 012 0v1h2V2a1 1 0 112 0v1h2a2 2 0 012 2v2h1a1 1 0 110 2h-1v2h1a1 1 0 110 2h-1v2a2 2 0 01-2 2h-2v1a1 1 0 11-2 0v-1H9v1a1 1 0 11-2 0v-1H5a2 2 0 01-2-2v-2H2a1 1 0 110-2h1V9H2a1 1 0 010-2h1V5a2 2 0 012-2h2V2zM5 5h10v10H5V5z" clipRule="evenodd" />
                                        </svg>
                                    </div>
                                </div>
                                {/* Orbiting elements */}
                                <div className="absolute top-0 left-1/2 -ml-4 w-8 h-8 bg-blue-300 rounded-full animate-bounce shadow-lg"></div>
                                <div className="absolute bottom-0 right-0 w-6 h-6 bg-green-300 rounded-full animate-ping shadow-lg"></div>
                                <div className="absolute top-1/2 left-0 -mt-3 w-6 h-6 bg-purple-300 rounded-full animate-pulse shadow-lg"></div>
                            </div>
                            <div className="mt-4 bg-white/20 backdrop-blur-md rounded-2xl p-6 border border-white/30 text-center">
                                <div className="text-6xl font-black mb-2 bg-gradient-to-r from-yellow-200 to-orange-200 bg-clip-text text-transparent">{clusters.length}</div>
                                <div className="text-blue-50 font-bold text-lg">Teacher Clusters</div>
                                <div className="text-blue-200 text-sm mt-1">AI-Analyzed Groups</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Clusters Section */}
            <div className="mb-8">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Teacher Clusters</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {clusters.map((cluster, index) => (
                        <ClusterCard
                            key={cluster.id}
                            cluster={cluster}
                            index={index}
                            onGenerate={() => navigate('/generate', { state: { selectedCluster: cluster.id } })}
                        />
                    ))}
                </div>
            </div>

            {/* Quick Stats */}
            <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-4">Quick Stats</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <StatItem
                        icon={
                            <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                            </svg>
                        }
                        label="Total Teachers"
                        value={clusters.reduce((sum, c) => sum + c.teacher_count, 0).toLocaleString()}
                        color="text-blue-600"
                    />
                    <StatItem
                        icon={
                            <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
                            </svg>
                        }
                        label="Avg Competency"
                        value={Math.round(clusters.reduce((sum, c) => sum + c.avg_score, 0) / clusters.length) + '%'}
                        color="text-green-600"
                    />
                    <StatItem
                        icon={
                            <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
                            </svg>
                        }
                        label="Clusters Analyzed"
                        value={clusters.length}
                        color="text-purple-600"
                    />
                </div>
            </div>
        </div>
    )
}

function ClusterCard({ cluster, index, onGenerate }) {
    const getClusterIcon = (id) => {
        const icons = {
            'A': (
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z" />
                </svg>
            ),
            'B': (
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M4 4a2 2 0 012-2h8a2 2 0 012 2v12a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm3 1h6v4H7V5zm8 8v2h1v-2h-1zm-2-2H7v4h6v-4zm2 0h1V9h-1v2zm1-4V5h-1v2h1zM5 5v2H4V5h1zm0 4H4v2h1V9zm-1 4h1v2H4v-2z" clipRule="evenodd" />
                </svg>
            ),
            'C': (
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
                </svg>
            )
        };
        return icons[id] || icons['A'];
    };

    return (
        <div
            className="group card hover:scale-105 hover:shadow-2xl cursor-pointer fade-in relative overflow-hidden"
            style={{ animationDelay: `${index * 100}ms` }}
        >
            {/* Decorative corner accent */}
            <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${cluster.color} opacity-10 rounded-bl-full transform group-hover:scale-150 transition-transform duration-500`}></div>

            {/* Cluster Header */}
            <div className={`relative bg-gradient-to-br ${cluster.color} rounded-xl p-5 mb-5 text-white shadow-lg`}>
                <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center">
                        <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl mr-3">
                            {getClusterIcon(cluster.id)}
                        </div>
                        <div>
                            <h3 className="text-3xl font-black">Cluster {cluster.id}</h3>
                            <p className="text-white/80 text-sm font-medium">{cluster.name.split(' - ')[1]}</p>
                        </div>
                    </div>
                    <div className="bg-white/25 backdrop-blur-md px-4 py-2 rounded-full text-sm font-bold border border-white/30">
                        <div className="flex items-center">
                            <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                            </svg>
                            {cluster.teacher_count}
                        </div>
                    </div>
                </div>
                <p className="text-sm text-white/90 leading-relaxed">{cluster.description}</p>
            </div>

            {/* Cluster Stats */}
            <div className="space-y-4 mb-5 relative z-10">
                <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl p-4">
                    <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center">
                            <div className={`bg-gradient-to-r ${cluster.color} p-2 rounded-lg mr-2`}>
                                <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
                                </svg>
                            </div>
                            <span className="text-gray-700 font-semibold text-sm">Competency Score</span>
                        </div>
                        <span className="font-black text-gray-800 text-lg">{cluster.avg_score}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                        <div
                            className={`bg-gradient-to-r ${cluster.color} h-3 rounded-full transition-all duration-1000 ease-out shadow-lg`}
                            style={{ width: `${cluster.avg_score}%` }}
                        ></div>
                    </div>
                </div>

                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4 border-l-4 border-indigo-500">
                    <div className="flex items-center">
                        <div className="bg-indigo-100 p-2 rounded-lg mr-3">
                            <svg className="w-5 h-5 text-indigo-600" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                            </svg>
                        </div>
                        <div>
                            <div className="text-xs text-gray-600 font-medium">Primary Training Need</div>
                            <div className="font-bold text-gray-800">{cluster.primary_need}</div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Action Button */}
            <button
                onClick={onGenerate}
                className="w-full btn-primary flex items-center justify-center group-hover:shadow-xl transition-all relative overflow-hidden"
            >
                <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 transform -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
                <svg className="w-5 h-5 mr-2 group-hover:rotate-12 group-hover:scale-110 transition-transform" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
                </svg>
                <span className="relative z-10">Generate Training Module</span>
            </button>
        </div>
    )
}

function StatItem({ icon, label, value, color }) {
    return (
        <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
            <div className={`${color}`}>
                {icon}
            </div>
            <div>
                <div className="text-2xl font-bold text-gray-800">{value}</div>
                <div className="text-sm text-gray-600">{label}</div>
            </div>
        </div>
    )
}
