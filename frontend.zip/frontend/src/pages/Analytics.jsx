import { useState, useEffect } from 'react'
import axios from 'axios'
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

export default function Analytics() {
    const [analytics, setAnalytics] = useState(null)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        fetchAnalytics()
    }, [])

    const fetchAnalytics = async () => {
        try {
            const response = await axios.get('/api/analytics')
            setAnalytics(response.data)
        } catch (error) {
            console.error('Error fetching analytics:', error)
            // Use fallback data if API fails
            setAnalytics(getFallbackAnalytics())
        } finally {
            setLoading(false)
        }
    }

    const getFallbackAnalytics = () => ({
        total_modules: 127,
        total_teachers_impacted: 2000,
        avg_generation_time: 28,
        modules_by_topic: [
            { name: 'FLN', value: 45, color: '#3B82F6' },
            { name: 'Science', value: 38, color: '#10B981' },
            { name: 'Math', value: 44, color: '#F59E0B' }
        ],
        modules_by_cluster: [
            { cluster: 'A', count: 42 },
            { cluster: 'B', count: 48 },
            { cluster: 'C', count: 37 }
        ],
        modules_by_language: [
            { name: 'Hindi', value: 78, color: '#F97316' },
            { name: 'English', value: 49, color: '#1E3A8A' }
        ],
        weekly_trend: [
            { week: 'Week 1', modules: 18 },
            { week: 'Week 2', modules: 25 },
            { week: 'Week 3', modules: 32 },
            { week: 'Week 4', modules: 28 },
            { week: 'Week 5', modules: 24 }
        ],
        duration_distribution: [
            { duration: '1 hour', count: 35 },
            { duration: '2 hours', count: 52 },
            { duration: '3 hours', count: 40 }
        ]
    })

    if (loading) {
        return (
            <div className="flex items-center justify-center h-96">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-primary mx-auto mb-4"></div>
                    <p className="text-gray-600 font-medium">Loading analytics...</p>
                </div>
            </div>
        )
    }

    return (
        <div className="fade-in">
            {/* Header */}
            <div className="relative bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-700 rounded-3xl shadow-2xl p-8 mb-8 text-white overflow-hidden">
                {/* Decorative elements */}
                <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl -mr-48 -mt-48"></div>
                <div className="absolute bottom-0 left-0 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl -ml-32 -mb-32"></div>

                <div className="relative z-10 flex items-center justify-between">
                    <div className="flex-1">
                        <div className="flex items-center mb-4">
                            <div className="bg-white/20 backdrop-blur-sm p-4 rounded-2xl mr-4">
                                <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
                                </svg>
                            </div>
                            <div>
                                <h1 className="text-5xl font-black mb-2">Analytics Dashboard</h1>
                                <p className="text-xl text-teal-100">Track your training module generation and impact</p>
                            </div>
                        </div>
                        <div className="flex items-center space-x-4">
                            <div className="flex items-center bg-white/15 backdrop-blur-md px-4 py-2 rounded-full border border-white/30">
                                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
                                </svg>
                                <span className="font-semibold text-sm">Real-time Data</span>
                            </div>
                            <div className="flex items-center bg-white/15 backdrop-blur-md px-4 py-2 rounded-full border border-white/30">
                                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M3 3a1 1 0 000 2v8a2 2 0 002 2h2.586l-1.293 1.293a1 1 0 101.414 1.414L10 15.414l2.293 2.293a1 1 0 001.414-1.414L12.414 15H15a2 2 0 002-2V5a1 1 0 100-2H3zm11.707 4.707a1 1 0 00-1.414-1.414L10 9.586 8.707 8.293a1 1 0 00-1.414 0l-2 2a1 1 0 101.414 1.414L8 10.414l1.293 1.293a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                                </svg>
                                <span className="font-semibold text-sm">Visual Insights</span>
                            </div>
                            <div className="flex items-center bg-white/15 backdrop-blur-md px-4 py-2 rounded-full border border-white/30">
                                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                                </svg>
                                <span className="font-semibold text-sm">Performance Metrics</span>
                            </div>
                        </div>
                    </div>
                    <div className="hidden xl:block">
                        <div className="w-32 h-32 relative">
                            <div className="absolute inset-0 bg-gradient-to-br from-yellow-300 to-orange-400 rounded-3xl animate-pulse shadow-2xl flex items-center justify-center rotate-12">
                                <svg className="w-20 h-20 text-white -rotate-12" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <MetricCard
                    title="Total Modules"
                    value={analytics.total_modules}
                    icon={
                        <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M9 4.804A7.968 7.968 0 005.5 4c-1.255 0-2.443.29-3.5.804v10A7.969 7.969 0 015.5 14c1.669 0 3.218.51 4.5 1.385A7.962 7.962 0 0114.5 14c1.255 0 2.443.29 3.5.804v-10A7.968 7.968 0 0014.5 4c-1.255 0-2.443.29-3.5.804V12a1 1 0 11-2 0V4.804z" />
                        </svg>
                    }
                    color="from-blue-500 to-blue-700"
                />
                <MetricCard
                    title="Teachers Impacted"
                    value={analytics.total_teachers_impacted.toLocaleString()}
                    icon={
                        <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                        </svg>
                    }
                    color="from-green-500 to-green-700"
                />
                <MetricCard
                    title="Avg Generation Time"
                    value={`${analytics.avg_generation_time}s`}
                    icon={
                        <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                        </svg>
                    }
                    color="from-orange-500 to-orange-700"
                />
                <MetricCard
                    title="Active Clusters"
                    value="3"
                    icon={
                        <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
                        </svg>
                    }
                    color="from-purple-500 to-purple-700"
                />
            </div>

            {/* Charts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                {/* Modules by Topic */}
                <ChartCard title="Modules by Topic">
                    <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                            <Pie
                                data={analytics.modules_by_topic}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                outerRadius={100}
                                fill="#8884d8"
                                dataKey="value"
                            >
                                {analytics.modules_by_topic.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                            </Pie>
                            <Tooltip />
                        </PieChart>
                    </ResponsiveContainer>
                </ChartCard>

                {/* Modules by Cluster */}
                <ChartCard title="Modules by Cluster">
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={analytics.modules_by_cluster}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="cluster" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey="count" fill="#1E3A8A" name="Modules Generated" />
                        </BarChart>
                    </ResponsiveContainer>
                </ChartCard>

                {/* Weekly Trend */}
                <ChartCard title="Weekly Generation Trend">
                    <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={analytics.weekly_trend}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="week" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="modules" stroke="#F97316" strokeWidth={3} name="Modules" />
                        </LineChart>
                    </ResponsiveContainer>
                </ChartCard>

                {/* Language Distribution */}
                <ChartCard title="Language Distribution">
                    <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                            <Pie
                                data={analytics.modules_by_language}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                outerRadius={100}
                                fill="#8884d8"
                                dataKey="value"
                            >
                                {analytics.modules_by_language.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                            </Pie>
                            <Tooltip />
                        </PieChart>
                    </ResponsiveContainer>
                </ChartCard>
            </div>

            {/* Duration Distribution */}
            <ChartCard title="Training Duration Distribution">
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={analytics.duration_distribution}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="duration" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="count" fill="#10B981" name="Number of Modules" />
                    </BarChart>
                </ResponsiveContainer>
            </ChartCard>
        </div>
    )
}

function MetricCard({ title, value, icon, color }) {
    return (
        <div className="card hover:scale-105 transition-transform">
            <div className={`bg-gradient-to-r ${color} rounded-lg p-4 mb-4 text-white`}>
                <div className="flex items-center justify-between">
                    <div>
                        <p className="text-sm text-white/80 mb-1">{title}</p>
                        <p className="text-3xl font-bold">{value}</p>
                    </div>
                    <div className="opacity-80">
                        {icon}
                    </div>
                </div>
            </div>
        </div>
    )
}

function ChartCard({ title, children }) {
    return (
        <div className="card">
            <h3 className="text-xl font-bold text-gray-800 mb-6">{title}</h3>
            {children}
        </div>
    )
}
