# Shikshak.AI - Frontend Startup Script
# This script starts the React development server

Write-Host "🎨 Starting Shikshak.AI Frontend..." -ForegroundColor Cyan
Write-Host ""

# Check if node_modules exists
if (-not (Test-Path ".\node_modules")) {
    Write-Host "📦 Installing dependencies..." -ForegroundColor Yellow
    Write-Host "   This may take a few minutes on first run..." -ForegroundColor Gray
    npm install
    Write-Host "✅ Dependencies installed!" -ForegroundColor Green
    Write-Host ""
}

Write-Host "✅ Frontend is ready!" -ForegroundColor Green
Write-Host ""
Write-Host "🌐 Starting development server..." -ForegroundColor Cyan
Write-Host "   Frontend: http://localhost:5173" -ForegroundColor Cyan
Write-Host "   Press CTRL+C to stop" -ForegroundColor Gray
Write-Host ""
Write-Host "⚠️  Make sure backend is running on http://localhost:8000" -ForegroundColor Yellow
Write-Host ""

# Start the dev server
npm run dev
